def bleble(a, b) :
    return(a+b)